import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.io.FileWriter;
import java.util.Scanner;
import java.io.File;  // Import the File class
import java.io.IOException;
import java.io.FileNotFoundException;


public class Main {
    private static String[] sortCabin(String[] cabinarray) {  /*sort passenger's names in to the alphabetical oder*/
        for (int i = 0; i <cabinarray.length ; i++) {
            for (int j = i + 1; j < cabinarray.length; j++) {

                if (cabinarray[i].compareTo(cabinarray[j]) > 0) {
                    String temp;
                    temp = cabinarray[i];
                    cabinarray[i] = cabinarray[j];
                    cabinarray[j] = temp;
                }
            }
        }
        for (int i = 0; i < cabinarray.length; i++) { /*ignore word empty from printing*/
            if(!cabinarray[i].equals("Empty")){
                System.out.println(cabinarray[i]);
            }

        }
        return cabinarray;
    }


    private static String[] loadfiles(String[] cabinarray) {
        File myObj = new File("SavedData.txt");
        if (myObj.exists()) {                                        /*Loading pre entered data */
            System.out.println("File name: " + myObj.getName());
            System.out.println("Absolute path: " + myObj.getAbsolutePath());

        } else {
            System.out.println("The file does not exist.");
        }
        return cabinarray;
    }


    private static String[] savefiles(String[] cabinarray) {
        try {
            FileWriter savedata = new FileWriter("SavedData.txt"); //creat a new object type file writer
            for (int i = 0; i < cabinarray.length; i++)
            {
                savedata.write("cabin"+i+":"+cabinarray[i]+"\n");
            }

            savedata.close();
            System.out.println("The file was successfully written to..");
        }catch (IOException e) {
            System.out.println("There was a mistake.");
            e.printStackTrace();
        }
        return cabinarray;
    }


    private static String[] findcabin(String[] cabinarray) {
        System.out.println("Find cabin from customer name");//finding exact data related to passengers name
        Scanner input = new Scanner(System.in);
        String name = input.next();
        int i;
        for (i = 0; i < cabinarray.length; i++) {

            if (cabinarray[i].equals(name) ) {
                System.out.println(i);
            }
        }
        return cabinarray;
    }


    private static String[] deletecabins(String[] cabinarray) {
        Scanner input= new Scanner(System.in);            //deleting passenger's data according to cabin number
        System.out.println("Enter the cabin number you want to remove a passenger");
        int i=input.nextInt();
        cabinarray[i]="Empty";
        return cabinarray;
    }


    private static String[] emptycabins(String[] cabinarray) {
        System.out.println("Display all empty cabins");          //display free cabins to let
        for(int i =0; i<cabinarray.length ;i++)
        {
            if (cabinarray[i]=="Empty"){
                System.out.println("cabin"+(i)+"-"+cabinarray[i]);
            }
        }

        return cabinarray;
    }


    private static String[] addcabins(String[] cabinarray) {
        try {
            Scanner input = new Scanner(System.in);
            System.out.print("Enter a cabin number to add passenger(0-11)");
            int i = input.nextInt();
            if (cabinarray[i] != "Empty") {
                System.out.println("A Passenger is in this cabin"); //check is booth is empty if it empty add a passenger
            }                                                        //if not print a message
            if (cabinarray[i] == "Empty") {


                System.out.print("Enter Passenger Name:");
                cabinarray[i] = input.next();
            }
            return cabinarray;
        }catch (Exception e){
            System.out.println("invalide input");
        }
        return cabinarray;
    }



    public static String[] viewcabin(String[] cabinarray) {
        System.out.println("view all cabins");
        for (int i = 0; i < cabinarray.length ; i++)     //printing data about availability
        {
            System.out.println("cabin "+(i)+":"+cabinarray[i]);
        }
        return cabinarray;
    }


    public static void main(String[] args) {
        String menu;
        String[] cabinarray = new String[12 ];           //create array
        System.out.println("Enter the following commend:");//given inputs
        System.out.println("A - Adds customer to cabin");
        System.out.println("V - view all cabins");
        System.out.println("E - Display Empty cabins");
        System.out.println("D - Delete customer from cabin");
        System.out.println("F - Find cabin from customer name");
        System.out.println("S - Store program data into file");
        System.out.println("L - Load program data from file");
        System.out.println("O - View passengers Ordered alphabetically by name");

        Scanner scanchoice = new Scanner(System.in);
        System.out.println();
        System.out.println("Enter \"A\", \"V\", \"E\", \"D\", \"F\", \"S\", \"L\" or \"O\" ");


        for (int i = 0; i < cabinarray.length ; i++)
        {
            cabinarray[i]="Empty"; //initialize cabin elements
        }

        while(true){
            System.out.print("Enter a Input-");
            menu = scanchoice.next();

            // calling methods according to the user inputs
            if (menu.equals("V")) {
                cabinarray=viewcabin(cabinarray);
            } else if (menu.equals("A")) {
                cabinarray=addcabins(cabinarray);

            } else if (menu.equals("E")) {
                cabinarray=emptycabins(cabinarray);

            } else if (menu.equals("D")) {
                cabinarray=deletecabins(cabinarray);

            }else if (menu.equals("F")) {
                cabinarray=findcabin(cabinarray);

            } else if (menu.equals("S")) {
                cabinarray=savefiles(cabinarray);

            } else if (menu.equals("L")){
                cabinarray=loadfiles(cabinarray);

            } else if (menu.equals("O")) {
                cabinarray=sortCabin(cabinarray);

            }
            else {
                System.out.println("Invalid Input");

            }

        }
    }
}

//refernce --->https://www.w3schools.com/java/java_files_create.asp(save data)
//https://www.w3schools.com/java/java_files_read.asp(Read data)








